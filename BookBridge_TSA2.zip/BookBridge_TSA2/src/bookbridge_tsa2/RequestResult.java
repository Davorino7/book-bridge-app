package bookbridge_tsa2;

public final class RequestResult {
    private final Member member;
    private final LibraryBook book;
    private final int requestedDays;
    private final int lateDays;
    private final RequestStatus status;
    private final LoanRecord loanRecord;
    private final Reservation reservation;
    private final double estimatedLateCharge;

    RequestResult(Member member, LibraryBook book, int requestedDays, int lateDays,
            RequestStatus status, LoanRecord loanRecord, Reservation reservation) {
        if (member == null || book == null || status == null) {
            throw new IllegalArgumentException(
                    "A request result needs a member, book, and status.");
        }
        if (requestedDays < 1 || requestedDays > 30) {
            throw new IllegalArgumentException(
                    "Requested days must be between 1 and 30.");
        }
        if (lateDays < 0) {
            throw new IllegalArgumentException("Late days cannot be negative.");
        }
        if (loanRecord != null && reservation != null) {
            throw new IllegalArgumentException(
                    "A request cannot create both a loan and a reservation.");
        }

        this.member = member;
        this.book = book;
        this.requestedDays = requestedDays;
        this.lateDays = lateDays;
        this.status = status;
        this.loanRecord = loanRecord;
        this.reservation = reservation;
        this.estimatedLateCharge = member.calculateFine(lateDays);
    }

    public Member getMember() { return member; }
    public LibraryBook getBook() { return book; }
    public int getRequestedDays() { return requestedDays; }
    public int getLateDays() { return lateDays; }
    public RequestStatus getStatus() { return status; }
    public LoanRecord getLoanRecord() { return loanRecord; }
    public Reservation getReservation() { return reservation; }
    public double getEstimatedLateCharge() { return estimatedLateCharge; }
}