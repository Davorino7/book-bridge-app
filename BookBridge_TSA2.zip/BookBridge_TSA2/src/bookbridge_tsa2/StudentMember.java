package bookbridge_tsa2;

public final class StudentMember extends Member {
    public static final int MAXIMUM_LOAN_DAYS = 14;
    public static final double DAILY_FINE = 5.0;

    public StudentMember(String memberId, String name) {
        super(memberId, name);
    }

    @Override
    public int getMaximumLoanDays() {
        return MAXIMUM_LOAN_DAYS;
    }

    @Override
    public double getDailyFine() {
        return DAILY_FINE;
    }
}