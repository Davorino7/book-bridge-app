package bookbridge_tsa2;

public final class LibraryService {
    public RequestResult processRequest(Member member, LibraryBook book,
            int requestedDays, int lateDays) {
        if (member == null || book == null) {
            throw new IllegalArgumentException(
                    "A request needs a member and a book.");
        }
        if (requestedDays < 1 || requestedDays > 30) {
            throw new IllegalArgumentException(
                    "Requested days must be between 1 and 30.");
        }
        if (lateDays < 0) {
            throw new IllegalArgumentException("Late days cannot be negative.");
        }

        RequestStatus status;
        LoanRecord loan = null;
        Reservation reservation = null;

        if (!book.isAvailable()) {
            status = RequestStatus.RESERVED;
            reservation = new Reservation(member, book, requestedDays);
        } else if (requestedDays > member.getMaximumLoanDays()) {
            status = RequestStatus.DENIED;
        } else {
            status = RequestStatus.APPROVED;
            loan = new LoanRecord(member, book, requestedDays);
            book.markBorrowed();
        }

        return new RequestResult(member, book, requestedDays, lateDays,
                status, loan, reservation);
    }
}