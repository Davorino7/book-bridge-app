package bookbridge_tsa2;

public final class Reservation {
    private final Member member;
    private final LibraryBook book;
    private final int requestedDays;

    Reservation(Member member, LibraryBook book, int requestedDays) {
        if (member == null || book == null) {
            throw new IllegalArgumentException(
                    "A reservation needs a member and a book.");
        }
        if (book.isAvailable()) {
            throw new IllegalArgumentException(
                    "A reservation requires an unavailable book.");
        }
        if (requestedDays < 1 || requestedDays > 30) {
            throw new IllegalArgumentException(
                    "Requested days must be between 1 and 30.");
        }

        this.member = member;
        this.book = book;
        this.requestedDays = requestedDays;
    }

    public Member getMember() {
        return member;
    }

    public LibraryBook getBook() {
        return book;
    }

    public int getRequestedDays() {
        return requestedDays;
    }
}