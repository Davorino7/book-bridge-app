package bookbridge_tsa2;

public interface Fineable {
    double calculateFine(int lateDays);
}