package bookbridge_tsa2;

public final class LibraryBook {
    private final String isbn;
    private final String title;
    private boolean available;

    public LibraryBook(String isbn, String title, boolean available) {
        this.isbn = Member.requireText(isbn, "ISBN");
        this.title = Member.requireText(title, "Book title");
        this.available = available;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public boolean isAvailable() {
        return available;
    }

    void markBorrowed() {
        if (!available) {
            throw new IllegalStateException("This book is already unavailable.");
        }
        available = false;
    }

    public void markReturned() {
        if (available) {
            throw new IllegalStateException("This book is already available.");
        }
        available = true;
    }
}