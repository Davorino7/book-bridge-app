package bookbridge_tsa2;

import java.util.concurrent.atomic.AtomicInteger;

public final class LoanRecord {
    private static final AtomicInteger NEXT_LOAN_NUMBER = new AtomicInteger(1);

    private final String loanId;
    private final Member member;
    private final LibraryBook book;
    private final int requestedDays;
    private boolean returned;
    private double finePaidOrDue;

    LoanRecord(Member member, LibraryBook book, int requestedDays) {
        if (member == null || book == null) {
            throw new IllegalArgumentException("A loan needs a member and a book.");
        }
        if (requestedDays < 1 || requestedDays > 30
                || requestedDays > member.getMaximumLoanDays()) {
            throw new IllegalArgumentException(
                    "Requested days exceed the allowed loan period.");
        }

        this.loanId = "L" + NEXT_LOAN_NUMBER.getAndIncrement();
        this.member = member;
        this.book = book;
        this.requestedDays = requestedDays;
        this.returned = false;
        this.finePaidOrDue = 0.0;
    }

    public String getLoanId() {
        return loanId;
    }

    public Member getMember() {
        return member;
    }

    public LibraryBook getBook() {
        return book;
    }

    public int getRequestedDays() {
        return requestedDays;
    }

    public boolean isReturned() {
        return returned;
    }

    public double getFinePaidOrDue() {
        return finePaidOrDue;
    }

    public void markReturned(int lateDays) {
        if (lateDays < 0) {
            throw new IllegalArgumentException("Late days cannot be negative.");
        }
        if (returned) {
            throw new IllegalStateException("This loan has already been returned.");
        }

        finePaidOrDue = member.calculateFine(lateDays);
        returned = true;
        book.markReturned();
    }
}