package bookbridge_tsa2;

public enum RequestStatus {
    APPROVED,
    RESERVED,
    DENIED
}