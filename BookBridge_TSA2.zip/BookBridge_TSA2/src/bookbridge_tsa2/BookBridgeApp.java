package bookbridge_tsa2;
import java.util.Scanner;

public final class BookBridgeApp {
    private static final int TRANSACTION_COUNT = 5;

    private BookBridgeApp() { }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        LibraryService service = new LibraryService();
        Summary summary = new Summary();

        System.out.println("=== BookBridge Library Request Console ===");
        System.out.println("Enter " + TRANSACTION_COUNT + " borrowing requests.\n");

        for (int i = 1; i <= TRANSACTION_COUNT; i++) {
            System.out.println("--- Transaction " + i + " of "
                    + TRANSACTION_COUNT + " ---");

            Member member = readMember(input);
            LibraryBook book = new LibraryBook(
                    readRequiredText(input, "ISBN: "),
                    readRequiredText(input, "Book Title: "),
                    readAvailability(input));

            int requestedDays = readInteger(
                    input, "Requested Loan Days (1-30): ", 1, 30);
            int lateDays = readInteger(
                    input, "Late Days (0 if none): ", 0, Integer.MAX_VALUE);

            RequestResult result = service.processRequest(
                    member, book, requestedDays, lateDays);

            printResult(i, result);
            summary.add(result);
        }

        summary.print();
        input.close();
    }

    private static Member readMember(Scanner input) {
        String id = readRequiredText(input, "Member ID: ");
        String name = readRequiredText(input, "Member Name: ");

        while (true) {
            String type = readRequiredText(input,
                    "Membership Type (STUDENT/FACULTY/GUEST): ").toUpperCase();

            switch (type) {
                case "STUDENT":
                    return new StudentMember(id, name);
                case "FACULTY":
                    return new FacultyMember(id, name);
                case "GUEST":
                    return new GuestMember(id, name);
                default:
                    System.out.println("Use STUDENT, FACULTY, or GUEST.");
            }
        }
    }

    private static String readRequiredText(Scanner input, String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = input.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("This field cannot be blank. Try again.");
        }
    }

    private static boolean readAvailability(Scanner input) {
        while (true) {
            System.out.print("Is the book available right now? (Y/N): ");
            String value = input.nextLine().trim().toUpperCase();

            if (value.equals("Y")) {
                return true;
            }
            if (value.equals("N")) {
                return false;
            }
            System.out.println("Please answer Y or N.");
        }
    }

    private static int readInteger(Scanner input, String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);

            try {
                int value = Integer.parseInt(input.nextLine().trim());

                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("Enter a whole number from " + min
                        + " to " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private static void printResult(int number, RequestResult result) {
        Member member = result.getMember();

        System.out.println("\nResult for Transaction " + number + ":");
        System.out.println("  Member: " + member.getName());
        System.out.println("  Book: " + result.getBook().getTitle());
        System.out.println("  Status: " + result.getStatus());
        System.out.println("  Max allowed days for this member: "
                + member.getMaximumLoanDays());
        System.out.printf("  Late fee rate: PHP %.2f/day%n",
                member.getDailyFine());
        System.out.printf("  Estimated late charge: PHP %.2f%n%n",
                result.getEstimatedLateCharge());
    }

    private static final class Summary {
        private int approved;
        private int reserved;
        private int denied;
        private double totalLateCharge;
        private RequestResult longest;

        void add(RequestResult result) {
            switch (result.getStatus()) {
                case APPROVED:
                    approved++;
                    break;
                case RESERVED:
                    reserved++;
                    break;
                case DENIED:
                    denied++;
                    break;
            }

            totalLateCharge += result.getEstimatedLateCharge();

            if (longest == null
                    || result.getRequestedDays() > longest.getRequestedDays()) {
                longest = result;
            }
        }

        void print() {
            System.out.println("=== Operational Summary ===");
            System.out.println("Approved: " + approved);
            System.out.println("Reserved: " + reserved);
            System.out.println("Denied: " + denied);
            System.out.println("Longest request: "
                    + longest.getMember().getName() + " ("
                    + longest.getMember().getMemberId() + "), "
                    + longest.getRequestedDays() + " days");
            System.out.printf("Total estimated late charge: PHP %.2f%n",
                    totalLateCharge);
        }
    }
}