package bookbridge_tsa2;

public final class TSA2Checks {
    private static int checks;

    private TSA2Checks() { }

    public static void main(String[] args) {
        testStudentBoundaryApproval();
        testUnavailableFacultyReservation();
        testGuestOverLimitDenial();
        testConstructorAndInputValidation();
        testLoanReturnAndSingleReturnRule();
        testOriginalFiveTransactionRegression();
        testMemberReferenceDispatch();
        testFineableInterfaceDispatch();

        System.out.println("Passed " + checks
                + " TSA2 checks across 8 test groups.");
    }

    private static void testStudentBoundaryApproval() {
        LibraryBook book = new LibraryBook("B-1", "Boundary Test", true);
        RequestResult result = new LibraryService().processRequest(
                new StudentMember("S-1", "Ana"), book, 14, 2);

        equal(RequestStatus.APPROVED, result.getStatus(), "student 14 days");
        check(result.getLoanRecord() != null, "approved result has a loan");
        check(!book.isAvailable(), "approved book becomes unavailable");
    }

    private static void testUnavailableFacultyReservation() {
        LibraryBook book = new LibraryBook("B-2", "Unavailable Test", false);
        RequestResult result = new LibraryService().processRequest(
                new FacultyMember("F-1", "Ben"), book, 20, 0);

        equal(RequestStatus.RESERVED, result.getStatus(), "unavailable book");
        check(result.getReservation() != null,
                "reserved result has a reservation");
        check(result.getLoanRecord() == null,
                "reserved result has no loan");
    }

    private static void testGuestOverLimitDenial() {
        LibraryBook book = new LibraryBook("B-3", "Over Limit Test", true);
        RequestResult result = new LibraryService().processRequest(
                new GuestMember("G-1", "Cara"), book, 8, 3);

        equal(RequestStatus.DENIED, result.getStatus(), "guest 8 days");
        check(book.isAvailable(), "denied book remains available");
        equal(30.0, result.getEstimatedLateCharge(), "guest late estimate");
    }

    private static void testConstructorAndInputValidation() {
        expectIllegal(() -> new StudentMember("  ", "Name"), "blank member ID");
        expectIllegal(() -> new GuestMember("G-2", "  "), "blank member name");
        expectIllegal(() -> new LibraryBook("B-4", " ", true), "blank title");

        expectIllegal(() -> new LibraryService().processRequest(
                new StudentMember("S-2", "Ella"),
                new LibraryBook("B-5", "Days", true), 0, 0),
                "zero requested days");

        expectIllegal(() -> new LibraryService().processRequest(
                new StudentMember("S-3", "Ella"),
                new LibraryBook("B-6", "Late", true), 1, -1),
                "negative late days");
    }

    private static void testLoanReturnAndSingleReturnRule() {
        LibraryBook book = new LibraryBook("B-7", "Return Test", true);
        RequestResult result = new LibraryService().processRequest(
                new FacultyMember("F-2", "Mina"), book, 30, 0);

        LoanRecord loan = result.getLoanRecord();
        loan.markReturned(3);

        check(loan.isReturned(), "loan is marked returned");
        check(book.isAvailable(), "returned book is available");
        equal(6.0, loan.getFinePaidOrDue(), "faculty return fine");
        expectIllegalState(() -> loan.markReturned(0), "second return");
    }

    private static void testOriginalFiveTransactionRegression() {
        LibraryService service = new LibraryService();

        RequestResult[] results = {
            service.processRequest(new StudentMember("S001", "Ana Cruz"),
                    new LibraryBook("9780134685991", "Effective Java", true),
                    14, 2),
            service.processRequest(new FacultyMember("F002", "Ben Reyes"),
                    new LibraryBook("9780596009205", "Head First Java", false),
                    30, 0),
            service.processRequest(new GuestMember("G003", "Cara Lim"),
                    new LibraryBook("9780132350884", "Clean Code", true),
                    8, 3),
            service.processRequest(new GuestMember("G004", "Dan Go"),
                    new LibraryBook("9780321356680",
                            "Java Concurrency in Practice", true), 7, 1),
            service.processRequest(new StudentMember("S005", "Ella Tan"),
                    new LibraryBook("9780596007126",
                            "Head First Design Patterns", false), 20, 4)
        };

        RequestStatus[] expected = {
            RequestStatus.APPROVED,
            RequestStatus.RESERVED,
            RequestStatus.DENIED,
            RequestStatus.APPROVED,
            RequestStatus.RESERVED
        };

        int approved = 0;
        int reserved = 0;
        int denied = 0;
        double total = 0.0;
        RequestResult longest = null;

        for (int i = 0; i < results.length; i++) {
            equal(expected[i], results[i].getStatus(),
                    "sample transaction " + (i + 1));

            switch (results[i].getStatus()) {
                case APPROVED:
                    approved++;
                    break;
                case RESERVED:
                    reserved++;
                    break;
                case DENIED:
                    denied++;
                    break;
            }

            total += results[i].getEstimatedLateCharge();

            if (longest == null
                    || results[i].getRequestedDays() > longest.getRequestedDays()) {
                longest = results[i];
            }
        }

        equal(2, approved, "sample approved count");
        equal(2, reserved, "sample reserved count");
        equal(1, denied, "sample denied count");
        equal("Ben Reyes", longest.getMember().getName(),
                "longest request name");
        equal("F002", longest.getMember().getMemberId(),
                "longest request member ID");
        equal(30, longest.getRequestedDays(), "longest request days");
        equal(70.0, total, "sample total late charge");
    }

    private static void testMemberReferenceDispatch() {
        Member[] members = {
            new StudentMember("S-4", "Student"),
            new FacultyMember("F-3", "Faculty"),
            new GuestMember("G-3", "Guest")
        };

        int[] days = {14, 30, 7};
        double[] fines = {5.0, 2.0, 10.0};

        for (int i = 0; i < members.length; i++) {
            equal(days[i], members[i].getMaximumLoanDays(),
                    "dispatch maximum " + i);
            equal(fines[i], members[i].getDailyFine(),
                    "dispatch fine rate " + i);
        }
    }

    private static void testFineableInterfaceDispatch() {
        Fineable studentFine =
                new StudentMember("S-5", "Student fine test");
        Fineable facultyFine =
                new FacultyMember("F-4", "Faculty fine test");
        Fineable guestFine =
                new GuestMember("G-4", "Guest fine test");

        equal(10.0, studentFine.calculateFine(2),
                "student Fineable dispatch");
        equal(4.0, facultyFine.calculateFine(2),
                "faculty Fineable dispatch");
        equal(20.0, guestFine.calculateFine(2),
                "guest Fineable dispatch");
    }

    private static void check(boolean condition, String label) {
        checks++;
        if (!condition) {
            throw new AssertionError(label);
        }
    }

    private static void equal(Object expected, Object actual, String label) {
        checks++;
        if (!expected.equals(actual)) {
            throw new AssertionError(label + ": expected "
                    + expected + ", got " + actual);
        }
    }

    private static void equal(double expected, double actual, String label) {
        checks++;
        if (Math.abs(expected - actual) > 0.000001) {
            throw new AssertionError(label + ": expected "
                    + expected + ", got " + actual);
        }
    }

    private static void equal(int expected, int actual, String label) {
        checks++;
        if (expected != actual) {
            throw new AssertionError(label + ": expected "
                    + expected + ", got " + actual);
        }
    }

    private static void equal(RequestStatus expected, RequestStatus actual,
            String label) {
        checks++;
        if (expected != actual) {
            throw new AssertionError(label + ": expected "
                    + expected + ", got " + actual);
        }
    }

    private static void expectIllegal(Runnable action, String label) {
        checks++;
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError(label + " should reject invalid input");
    }

    private static void expectIllegalState(Runnable action, String label) {
        checks++;
        try {
            action.run();
        } catch (IllegalStateException expected) {
            return;
        }
        throw new AssertionError(label + " should reject invalid state");
    }
}