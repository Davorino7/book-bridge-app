package bookbridge_tsa2;

public final class GuestMember extends Member {
    public static final int MAXIMUM_LOAN_DAYS = 7;
    public static final double DAILY_FINE = 10.0;

    public GuestMember(String memberId, String name) {
        super(memberId, name);
    }

    @Override
    public int getMaximumLoanDays() {
        return MAXIMUM_LOAN_DAYS;
    }

    @Override
    public double getDailyFine() {
        return DAILY_FINE;
    }
}