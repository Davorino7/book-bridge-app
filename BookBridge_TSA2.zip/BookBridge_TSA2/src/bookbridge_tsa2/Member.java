package bookbridge_tsa2;

public abstract class Member implements Fineable {
    private final String memberId;
    private final String name;

    protected Member(String memberId, String name) {
        this.memberId = requireText(memberId, "Member ID");
        this.name = requireText(name, "Member name");
    }

    public final String getMemberId() {
        return memberId;
    }

    public final String getName() {
        return name;
    }

    public abstract int getMaximumLoanDays();

    public abstract double getDailyFine();

    @Override
    public final double calculateFine(int lateDays) {
        if (lateDays < 0) {
            throw new IllegalArgumentException("Late days cannot be negative.");
        }
        return lateDays * getDailyFine();
    }

    static String requireText(String value, String label) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(label + " cannot be blank.");
        }
        return value.trim();
    }
}