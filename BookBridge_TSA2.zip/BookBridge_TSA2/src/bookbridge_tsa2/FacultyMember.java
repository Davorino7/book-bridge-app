package bookbridge_tsa2;

public final class FacultyMember extends Member {
    public static final int MAXIMUM_LOAN_DAYS = 30;
    public static final double DAILY_FINE = 2.0;

    public FacultyMember(String memberId, String name) {
        super(memberId, name);
    }

    @Override
    public int getMaximumLoanDays() {
        return MAXIMUM_LOAN_DAYS;
    }

    @Override
    public double getDailyFine() {
        return DAILY_FINE;
    }
}